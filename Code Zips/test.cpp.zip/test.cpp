// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset( new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
// is the collection created
ASSERT_TRUE(collection);

// if empty, the size must be 0
ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

// if empty, the size must be 0
ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//FAIL();
//}

TEST_F(CollectionTest, CanAddToEmptyVector)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

// if empty, the size must be 0
ASSERT_EQ(collection->size(), 0);

add_entries(1);

// is the collection still empty?
ASSERT_FALSE(collection->empty());

// if not empty, what must the size be?
ASSERT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

add_entries(5);

// what is its size now?
ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
// is the max size greater than or equal to the size for 0 entries?
ASSERT_GE(collection->max_size(), collection->size());

add_entries(1); // 1

// is the max size greater than or equal to the size for 1 entry?
ASSERT_GE(collection->max_size(), collection->size());

add_entries(4); // 5

// is the max size greater than or equal to the size for 5 entries?
ASSERT_GE(collection->max_size(), collection->size());

add_entries(5); // 10

// is the max size greater than or equal to the size for 10 entries?
ASSERT_GE(collection->max_size(), collection->size());
}

TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

// is the capacity greater than or equal to the size for 0 entries?
ASSERT_GE(collection->capacity(), collection->size());

add_entries(1); // 1

// is the capacity greater than or equal to the size for 1 entry?
ASSERT_GE(collection->capacity(), collection->size());

add_entries(4); // 5

// is the capacity greater than or equal to the size for 5 entries?
ASSERT_GE(collection->capacity(), collection->size());

add_entries(5); // 10

// is the capacity greater than or equal to the size for 10 entries?
ASSERT_GE(collection->capacity(), collection->size());
}

TEST_F(CollectionTest, ResizingIncreasesCollection)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

collection->resize(10);

// does the collection now have a size of 10?
ASSERT_EQ(collection->size(), 10);
}

TEST_F(CollectionTest, ResizingDecreasesCollection)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

add_entries(10);

// does the collection now have a size of 10?
ASSERT_EQ(collection->size(), 10);

collection->resize(5);

// does the collection now have a size of 5?
ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, ResizingDecreasesCollectionToZero)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

add_entries(10);

// does the collection now have a size of 10?
ASSERT_EQ(collection->size(), 10);

collection->resize(0);

// does the collection now have a size of 5?
ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ClearingErasesCollection)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

add_entries(10);

// does the collection now have a size of 10?
ASSERT_EQ(collection->size(), 10);

collection->clear();

// is the collection empty again?
ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, EraseBeginAndEndErasesCollection)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

add_entries(10);

// does the collection now have a size of 10?
ASSERT_EQ(collection->size(), 10);

collection->erase(collection->begin(), collection->end());

// is the collection empty again?
ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

// is the size 0?
ASSERT_EQ(collection->size(), 0);

// is the capacity 0?
ASSERT_EQ(collection->capacity(), 0);

collection->reserve(10);

// is the size still 0?
ASSERT_EQ(collection->size(), 0);

// is the capacity now 10?
ASSERT_EQ(collection->capacity(), 10);
}

TEST_F(CollectionTest, OutOfRangeThrownWithOutOfBoundsCollectionAtCall)
{
// does an out of bounds at() call throw std::out_of_range?
ASSERT_THROW(collection->at(-1), std::out_of_range);
}

TEST_F(CollectionTest, PopBackReducesSize)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

// is the size 0?
ASSERT_EQ(collection->size(), 0);

add_entries(5);

// is the size now 5?
ASSERT_EQ(collection->size(), 5);

collection->pop_back();

// is the size now 4?
ASSERT_EQ(collection->size(), 4);
}

TEST_F(CollectionTest, ReserveNegativeThrowsLengthError)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

// is the size 0?
ASSERT_EQ(collection->size(), 0);

// does reserving a negative number throw a length error?
ASSERT_THROW(collection->reserve(-1), std::length_error);
}
