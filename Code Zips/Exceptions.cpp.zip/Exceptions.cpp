// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <exception>

bool do_even_more_custom_application_logic()
{
  std::cout << "Running Even More Custom Application Logic." << std::endl;

  throw std::runtime_error("Custom application logic failed");

  return true;
}
void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;

  bool succeeded = false;
  try
  {
      succeeded = do_even_more_custom_application_logic();
  }
  catch (std::exception &e)
  {
      std::cout << "do_custom_application_logic caught an exception from do_even_more_custom_application_logic: " << e.what() << std::endl;
  }

  if (succeeded)
  {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
  }

  throw std::runtime_error("Uh oh! Something went wrong!");

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // If the denominator is zero, we can't divide. Throw a runtime_error.
  if (den == 0)
  {
      throw std::runtime_error("Math error: cannot divide by zero");
  }
  return (num / den);
}

void do_division() noexcept
{
  float numerator = 10.0f;
  float denominator = 0;

  float result;
  try
  {
      result = divide(numerator, denominator);
  }
  catch (std::runtime_error& e)
  {
      std::cout << "Caught std::runtime_error from do_division(): " << e.what() << std::endl;
      return;
  }
  std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
}

int main()
{
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();
    }
    catch (std::runtime_error& e)
    {
        std::cout << "Caught std::runtime_error from main(): " << e.what() << std::endl;
    }
    catch (std::exception& e)
    {
        std::cout << "Caught std::exception from main(): " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Caught unhandled exception from main()" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu